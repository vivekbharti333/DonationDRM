export interface Dropdown {
    label?:String;
    value?:String;
    permission?:String;
}

export class DropdownInterface {
    label?:String;
    value?:String;
}
