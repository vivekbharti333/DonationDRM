import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { IconModule } from '@coreui/icons-angular';

import { AddUserComponent } from './add-user/add-user.component';
import { UserListComponent } from './user-list/user-list.component';
import { ChangeUserComponent } from './change-user/change-user.component';
import { UserManagementRoutingModule } from './user-management-routing.module';
import {NgxPaginationModule} from 'ngx-pagination';

import {
  AvatarModule,
  BadgeModule,
  BreadcrumbModule,
  ButtonGroupModule,
  ButtonModule,
  CardModule,
  DropdownModule,
  FooterModule,
  FormModule,
  GridModule,
  HeaderModule,
  ListGroupModule,
  NavModule,
  ProgressModule,
  SharedModule,
  SidebarModule,
  TabsModule,
  UtilitiesModule,
  ModalModule,
  SpinnerModule,
} from '@coreui/angular';



@NgModule({
  declarations: [
    AddUserComponent,
    UserListComponent,
    ChangeUserComponent,
    
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    AvatarModule,
    IconModule,
    CardModule,
    BadgeModule,
    ModalModule,
    SpinnerModule,
    UserManagementRoutingModule,
    NgxPaginationModule
  ]
})
export class UserManagementModule { }
